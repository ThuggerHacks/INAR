import { Jogo } from "./jogo.js";

class No {
  constructor(tabuleiro) {
    this.tabuleiro = tabuleiro;
    this.filhos = [];
    this.caminhos = [];
    this.pai = null;
  }
}

class Arvore {
  constructor() {
    this.pilha = [this.raiz];
    this.objectivos = [];
    this.estadoInicial = [
      ["1", "2", "3"],
      ["4", "5", "6"],
      ["7", "", "8"]
    ];
    this.estadoFinal = [
      ["1", "2", "3"],
      ["4", "5", "6"],
      ["7", "8", ""]
    ];

    this.raiz = new No(this.estadoInicial);
  }


  buscaPorProfundidade(arvore) {

    if (arvore) {
      let jogo = new Jogo();
      this.estadoInicial = jogo.copiarValorArray(arvore.tabuleiro);
      this.pilha.pop();

      //verificar testeDeObjectivo para o pai
      if (jogo.testeDeObjectivo(arvore.tabuleiro, this.estadoFinal)) {
        this.objectivos.push(this.estadoFinal)
        console.log(this.objectivos)
        return;
      }

      let transicao = jogo.modeloDeTransacao(arvore.tabuleiro);

      if (transicao.length > 0) {
        let no;
        for (let i = 0; i < transicao.length; i++) {
          no = new No(transicao[i]);
          no.pai = arvore;
          no.caminhos.push(no.pai);
          no.caminhos.push(...no.pai.caminhos)
          if (arvore.pai) {
            if (jogo.testeDeObjectivo(transicao[i], arvore.pai.tabuleiro) == false) {
              //criar novo no com dados

              arvore.filhos.push(no)

              //verificar testeDeObjectivo para os filhos

              if (jogo.testeDeObjectivo(transicao[i], this.estadoFinal)) {
                this.objectivos.push(transicao[i])
                console.log(this.objectivos)
                return;
              }
            }
          } else {
            arvore.filhos.push(no)
            if (jogo.testeDeObjectivo(transicao[i], this.estadoFinal)) {
              this.objectivos.push(transicao[i])
              console.log(this.objectivos)
              return;
            }
          }
        }


      }

      //precorrer
      for (let i = arvore.filhos.length - 1; i > 0; i--) {
        if (arvore.pai) {
          if (jogo.testeDeObjectivo(arvore.pai.tabuleiro, arvore.filhos[i].tabuleiro) == false) {
            this.pilha.push(arvore.filhos[i]);
          }
        } else {
          this.pilha.push(arvore.filhos[i]);
        }
      }
      console.log(this.objectivos)
      this.buscaPorProfundidade(this.pilha[this.pilha.length - 1]);
    }

  }

  melhorSolucao() {
    let melhor = this.objectivos[0];
    for (let i = 0; i < this.objectivos.length; i++) {
      if (this.objectivos[i].length < melhor) {
        melhor = this.objectivos[i];
      }
    }

    return melhor;
  }

}

const arvore = new Arvore();

arvore.buscaPorProfundidade(arvore.raiz);
